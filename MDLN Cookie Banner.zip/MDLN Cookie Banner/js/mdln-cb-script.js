jQuery(document).ready(function($){
    if (document.cookie.includes("STYXKEY_mdln_cookie_banner_dismissed=1")) {
        $('#mdln-full-width-cookie-banner').hide();
    }

    $('#close-mdln-cookie-banner').on('click', function(){
        $('#mdln-full-width-cookie-banner').fadeOut(300);

        var days = parseInt(mdlnCookieBanner.dismiss_duration, 10) || 7;
        var date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        document.cookie = "STYXKEY_mdln_cookie_banner_dismissed=1; expires=" + date.toUTCString() + "; path=/";
    });
});