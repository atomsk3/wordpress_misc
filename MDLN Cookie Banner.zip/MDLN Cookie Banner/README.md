=== MDLN Notice Cookie Banner ===
Contributors: Ryan Cronin c/o Medline Industries, LP.
Tags: cookie, GDPR, banner, privacy
Requires at least: 5.0
Tested up to: 6.5
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

A lightweight, customizable cookie notice banner with template support and compatibility with Pantheon.io

== Description ==

This plugin displays a customizable cookie consent banner based on selectable HTML templates. Compatible with Pantheon's cookie handling system. It sets a cookie (`STYXKEY_mdln_cookie_banner_dismissed`) to record when a user closes the banner initially.

== Installation ==

1. Upload the plugin folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Choose your preferred banner template via the plugin settings page.

== Frequently Asked Questions ==

= Can I add my own templates? =
Yes, just place them in the `/options/templates/` directory using the `template-*.php` naming convention.

== Changelog ==

Version 1.0.0 – 2025-07-09
--------------------------
- Initial release of MDLN Notice Cookie Banner plugin.
- Added customizable cookie banner with dismiss functionality.
- Included support for template-based banner rendering. (ex: template-default.php, template-new.php)
- Integrated compatibility with Pantheon hosting, added required naming convention to cookies. (ex: STYXKEY_mdln_cookie_banner_dismissed)
- Added 'MDLN Cookie Banner' settings interface in WP Dashboard to select banner template.
- Added support for configurable cookie expiration duration in days.
- Compatibility with WordPress best practices, non-intrusive UI design, every PHP file includes 'absolute path' security check, deleted saved options via deactivation hook, etc.