<?php
 /**
 * MDLN Cookie Banner
 *
 * @package MDLN_Cookie_Banner
 * @author Ryan Cronin
 * @copyright Medline
 * @license GPL-2.0-or-later
 *
 * @license http://www.gnu.org/licenses/gpl-2.0.txt GPL-2.0+
 * @version 1.0.0
 *
 * Plugin Name: [MDLN] Cookie Banner
 * Plugin URI:
 * Description: A lightweight, customizable cookie notice banner with template support and compatibility with Pantheon.io
 * Version: 1.0.0
 * Author: Ryan Cronin c/o Medline Industries, LP.
 * Author URI: https://medline.com
 * Text Domain: mdln-cookie-banner
 * Domain Path: /lang
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

// Prevent direct file access to keep things secure
if (!defined('ABSPATH')) exit;

/**
 * Enqueues front-end styles and scripts for the cookie banner.
 * 
 * - CSS for visual styling
 * - JS for interactivity (dismissal logic)
 * - Localizes JS with user-defined options (dismiss duration)
 */
function mdln_cookie_banner_enqueue_scripts() {
    wp_enqueue_style(
        'mdln-cookie-banner-style',
        plugin_dir_url(__FILE__) . 'css/style.css'
    );

    wp_enqueue_script(
        'mdln-cookie-banner-script',
        plugin_dir_url(__FILE__) . 'js/mdln-cb-script.js',
        array('jquery'), // Load after jQuery
        null,
        true // Load in footer
    );

    // Pass server-side config into JS environment
    wp_localize_script('mdln-cookie-banner-script', 'mdlnCookieBanner', array(
        'dismiss_duration' => get_option('mdln_cookie_banner_duration', 7)
    ));
}
add_action('wp_enqueue_scripts', 'mdln_cookie_banner_enqueue_scripts');

/**
 * Adds a custom settings page under the WP Settings menu.
 * 
 * Purpose: gives users an admin interface to control banner behavior.
 */
function mdln_cookie_banner_menu() {
    add_options_page(
        'MDLN Cookie Banner Settings', // Page title
        'MDLN Cookie Banner',          // Menu label
        'manage_options',              // Required capability
        'mdln-cookie-banner',          // Slug
        'mdln_cookie_banner_settings_page' // Callback to render page
    );
}
add_action('admin_menu', 'mdln_cookie_banner_menu');

/**
 * Renders the actual HTML for our settings page.
 * 
 * This form uses native WordPress settings API hooks to handle data submission.
 */
function mdln_cookie_banner_settings_page() {
    ?>
    <div class="wrap">
        <h1>MDLN Cookie Banner Settings</h1>
        <form method="post" action="options.php">
            <?php
            settings_fields('mdln_cookie_banner_settings'); // Nonce + option group binding
            do_settings_sections('mdln-cookie-banner'); // Output registered sections/fields
            submit_button(); // Save button
            ?>
        </form>
    </div>
    <?php
}

/**
 * Registers our plugin's options and settings fields with WordPress.
 * 
 * We define:
 * - A dropdown for selecting a banner template
 * - A numeric input for controlling how many days until the banner reappears
 */
function mdln_cookie_banner_settings_init() {
    // Register both options with WordPress
    register_setting('mdln_cookie_banner_settings', 'mdln_cookie_banner_template');
    register_setting('mdln_cookie_banner_settings', 'mdln_cookie_banner_duration');

    // Define section heading for logical grouping
    add_settings_section(
        'mdln_cookie_banner_section',
        'MDLN Cookie Banner Settings',
        null, // Optional callback for section description
        'mdln-cookie-banner'
    );

    // Template file selection dropdown
    add_settings_field(
        'mdln_cookie_banner_template',
        'Select banner template.',
        'mdln_cookie_banner_template_field',
        'mdln-cookie-banner',
        'mdln_cookie_banner_section'
    );

    // Duration input field
    add_settings_field(
        'mdln_cookie_banner_duration',
        'How many days until the banner reappears after initial close? Enter a whole number.',
        'mdln_cookie_banner_duration_field',
        'mdln-cookie-banner',
        'mdln_cookie_banner_section'
    );
}
add_action('admin_init', 'mdln_cookie_banner_settings_init');

/**
 * Outputs the <select> element to choose a banner template.
 * 
 * It dynamically scans the `/options/templates` folder for any file 
 * that matches our naming convention: template-*.php
 */
function mdln_cookie_banner_template_field() {
    $selected = get_option('mdln_cookie_banner_template', 'template-default.php');

    // Only include files that start with 'template-' and end in '.php'
    $templates = array_filter(scandir(plugin_dir_path(__FILE__) . 'options/templates'), function($file) {
        return strpos($file, 'template-') === 0 && substr($file, -4) === '.php';
    });

    echo '<select name="mdln_cookie_banner_template">';
    foreach ($templates as $template) {
        $is_selected = selected($selected, $template, false);
        echo "<option value='$template' $is_selected>$template</option>";
    }
    echo '</select>';
}

/**
 * Outputs the input field to define how many days the banner should remain dismissed.
 */
function mdln_cookie_banner_duration_field() {
    $duration = get_option('mdln_cookie_banner_duration', 7);
    echo "<input type='number' name='mdln_cookie_banner_duration' value='" . esc_attr($duration) . "' min='1' />";
}

/**
 * Injects the cookie banner HTML into the footer unless the user has dismissed it.
 * 
 * - Checks for a cookie (set by JS on close)
 * - Includes the selected template
 */
function mdln_cookie_banner_render_banner() {
    // Respect the user's dismissal preference
    if (isset($_COOKIE['STYXKEY_mdln_cookie_banner_dismissed']) && $_COOKIE['STYXKEY_mdln_cookie_banner_dismissed'] == '1') {
        return;
    }

    // Determine which template should be rendered
    $template = get_option('mdln_cookie_banner_template', 'template-default.php');
    $template_path = plugin_dir_path(__FILE__) . 'options/templates/' . $template;

    // Include the template only if it physically exists
    if (file_exists($template_path)) {
        include $template_path;
    }
}
add_action('wp_footer', 'mdln_cookie_banner_render_banner');

/**
 * When the plugin is deactivated, clean up saved options from the DB.
 * 
 * This ensures a fresh state if the plugin is reinstalled or removed cleanly.
 */
register_deactivation_hook(__FILE__, 'mdln_cookie_banner_deactivate');
function mdln_cookie_banner_deactivate() {
    delete_option('mdln_cookie_banner_template');
    delete_option('mdln_cookie_banner_duration');
}