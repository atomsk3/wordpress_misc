<?php

// Standard 'absolute path' security check
if (!defined('ABSPATH')) exit; 

?>

<div id="mdln-cookie-banner">
    <div id="mdln-full-width-cookie-banner" class="mdln-cookie-banner-blue-theme">
        <button id="close-mdln-cookie-banner" aria-label="Close Notice">&times;</button>
        <h2 id="onetrust-policy-title">This website uses cookies.</h2>
		<div id="onetrust-policy-text">
			We use Functional and Performance cookies to offer you a better browsing experience, analyze site traffic, and to improve the website. This website is NOT collecting your personal data when you browse this website. By continuing to access this website, you agree to this use of cookies.
		</div>
    </div>
</div>